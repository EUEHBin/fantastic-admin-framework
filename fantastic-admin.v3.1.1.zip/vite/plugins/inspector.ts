import Inspector from 'vite-plugin-vue-inspector'

export default function createInspector() {
  return Inspector()
}

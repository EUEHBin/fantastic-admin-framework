<route lang="yaml">
meta:
  title: 导航2-2-2
</route>

<template>
  <div>
    <page-main>
      多级导航2-2-2
    </page-main>
  </div>
</template>

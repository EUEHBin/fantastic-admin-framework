<route lang="yaml">
meta:
  title: 导航1
</route>

<template>
  <div>
    <page-main>
      多级导航1
    </page-main>
  </div>
</template>

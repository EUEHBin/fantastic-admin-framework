const pinia = createPinia()

export default pinia
